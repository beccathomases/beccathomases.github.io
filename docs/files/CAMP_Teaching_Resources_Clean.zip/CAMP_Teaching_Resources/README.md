# CAMP Teaching Resources

**Computational and Applied Mathematics Practicum (CAMP)**  
Becca Thomases · Department of Mathematical Sciences, Smith College  
Developed with support from the Richard Lounsbery Foundation

## About CAMP

CAMP is an intensive, two-week introduction to computational and applied mathematics research. It combines short lessons, guided computational exercises, independent or small-group projects, research documentation, and low-stakes presentations. The emphasis is on learning *how to do research*: posing manageable questions, developing computational tools, troubleshooting, documenting progress, and communicating work in progress. Students do not need to arrive with a research project or previous research experience.

The program was piloted in May 2025 and January 2026. Smith College approved a credit-bearing version, **MTH 263**, for January 2027. The resources here include materials from the pilots and newer templates or activities prepared for subsequent offerings. They are adaptable examples, **not a fixed curriculum or a fully self-contained textbook**.

For an overview of implementation, see the accompanying *CAMP Replication Guide* [add link or include the PDF beside this ZIP].

## Folder guide

### `Program_Materials/`
Syllabi and schedules from different CAMP offerings, including the May 2025 pilot, the January 2026 pilot schedule, and the January 2027 course syllabus. These illustrate how the program has evolved. **Check dates, credit-hour rules, prerequisites, and assessment policies locally before adapting them.**

### `Student_Templates/`
Editable forms for day-to-day research practice:
- **Daily reflection:** progress, questions, obstacles, and a concrete plan for the next day.
- **Research memo:** context, methods, observations, unresolved questions, and next steps.
- **MATLAB Onramp pathways:** self-paced computational learning options.
- **Project scoping sheet:** narrowing a question into a feasible short project.

### `Computational_Activities/`
Selected MATLAB scripts, Live Scripts (`.mlx`), teaching examples, and associated data. The folders are named by **day/topic in the January 2026 teaching sequence**, but they need not be taught in that order.

| Folder/topic | Illustrative materials |
|---|---|
| Day 1 — Basic plotting | MATLAB plots and a starter script |
| Day 2 — Least squares and PCA | Introductory Live Scripts |
| Day 3 — PCA and SVD | Additional linear-algebra exploration materials |
| Day 4 — Exploratory data analysis | California housing data and a guided activity |
| Day 6 — Connect-K | Introductory reinforcement-learning code and extensions |
| Day 7 — ODEs and plotting | Linear/nonlinear dynamical-system examples |
| Day 8 — Image processing | **Leaf measurement activity**, with example images, a MATLAB script, student directions, and instructor notes |
| Day 9 — Git and coding | Introductory Git/GitHub material |

Some folders contain **instructor demonstrations or exploratory code rather than standalone assignments**. Read the files before using them in class and test them with your own MATLAB installation. The leaf activity was developed for the resource package **after the January 2026 pilot**; it should not be taken as documentation of an activity students completed during that pilot.

### `Presentations_and_Assessment/`
Materials for midpoint/final presentations and peer feedback, the January 2026 exit-survey questionnaire, a beginning/end self-assessment form, and a final portfolio assignment with S/U criteria. The newer assessment and portfolio templates are intended for the 2027 course and future adaptations, not presented as assessments administered in 2026.

## Suggested way to use this package

1. Read the replication guide, then choose the program schedule best suited to your cohort.
2. Check student software access before the first meeting. MATLAB is the primary platform; some activities may use particular toolboxes or supplementary tools.
3. Choose a **small selection** of computational examples suited to students' backgrounds rather than attempting every topic.
4. Introduce a daily reflection routine and brief research memos from the start.
5. Provide an early project-scoping conversation, time for independent work, and midpoint/final presentations.
6. Adapt the assessment and workload to your institution's requirements.

## Sharing, permissions, and attribution

- These materials are shared for educational adaptation; **no blanket license is granted here for embedded third-party code, documents, images, or datasets**. Check the provenance and redistribution terms for any material you plan to republish or modify.
- The California housing dataset is derived from 1990 U.S. Census data and is also distributed through StatLib/scikit-learn. Cite its original source and verify the applicable redistribution terms for your use.
- If your copy of this package contains research-specific experimental data (including any sperm-imaging `.mat` files), **remove it from a public download unless permission to redistribute it is confirmed**.
- Do not publish identifiable student work, reflections, or response datasets without appropriate consent. The student templates here are intended to be blank exemplars.

## Questions and updates

For context or questions about implementing CAMP, contact Becca Thomases through the Smith College Department of Mathematical Sciences.

**Package version:** October 2026 (working resource collection). Individual activities and templates may be revised for future offerings.
