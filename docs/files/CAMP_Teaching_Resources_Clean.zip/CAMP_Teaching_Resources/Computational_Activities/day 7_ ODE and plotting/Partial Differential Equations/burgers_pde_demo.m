%% burgers_ode_demo.m
% 1D viscous Burgers: u_t + u u_x = nu u_xx (periodic)
% Method of lines + ode15s + visualizations

clear; close all; clc

%% Parameters
L  = 1.0;        % domain length
N  = 256;        % number of grid points
nu = 2e-4;       % viscosity (try 1e-2 for smoother, 1e-4 for sharper)
tspan = [0 0.6]; % time interval

x  = (0:N-1)' * (L/N);     % periodic grid
dx = L/N;

% Initial condition (try changing this)
u0 = sin(2*pi*x/L) + 0.5*sin(4*pi*x/L);
% u0 = exp(-200*(x-0.3).^2) - exp(-200*(x-0.7).^2);  % another fun one

%% ODE solve (method of lines)
rhs = @(t,u) burgers_rhs_upwind(u, nu, dx);

opts = odeset( ...
    'RelTol',1e-6, ...
    'AbsTol',1e-8, ...
    'MaxStep', 5e-3 ...      % helps if you take small nu / steep gradients
);

[t, U] = ode15s(rhs, tspan, u0, opts);   % U is (length(t) x N)

%% Basic plots: space-time heatmap + surface
figure('Color','w');
tiledlayout(2,2,'Padding','compact','TileSpacing','compact');

% Snapshot at final time
nexttile;
plot(x, U(1,:), 'LineWidth', 1.5); hold on;
plot(x, U(end,:), 'LineWidth', 1.5);
xlabel('x'); ylabel('u(x,t)');
legend(sprintf('t=%.3f',t(1)), sprintf('t=%.3f',t(end)), 'Location','best');
title('Initial vs final');

% Space-time heatmap
nexttile;
imagesc(x, t, U);
set(gca,'YDir','normal');
xlabel('x'); ylabel('t');
title('u(x,t) heatmap');
colorbar;

% Surface plot
nexttile([1 2]);
surf(x, t, U, 'EdgeColor','none');
xlabel('x'); ylabel('t'); zlabel('u');
title('u(x,t) surface');
view(35, 35);
colorbar;

%% Animation: evolving profile + diagnostics
% Simple "energy" diagnostic (not exactly conserved with viscosity + upwind)
E = 0.5 * trapz(x, U.^2, 2);  % integrate in x for each time row

figure('Color','w');
tl = tiledlayout(1,2,'Padding','compact','TileSpacing','compact');

ax1 = nexttile;
h = plot(x, U(1,:), 'LineWidth', 2);
grid on; ylim([min(U(:)) max(U(:))]);
xlabel('x'); ylabel('u'); title('Animation');

ax2 = nexttile;
plot(t, E, 'LineWidth', 2);
grid on; xlabel('t'); ylabel('E(t) = 1/2 \int u^2 dx');
title('Energy-like diagnostic');

for k = 1:4:length(t)
    set(h, 'YData', U(k,:));
    title(ax1, sprintf('u(x,t),  t = %.4f', t(k)));
    drawnow;
end

%% ---------------- local function ----------------
function dudt = burgers_rhs_upwind(u, nu, dx)
% Periodic 1D viscous Burgers RHS with simple upwind advection.
%
% u_t = - u u_x + nu u_xx
% Advection: upwind on u_x based on sign(u)
% Diffusion: centered second difference

    % periodic neighbors
    up = circshift(u, -1);
    um = circshift(u,  1);

    % diffusion (centered)
    u_xx = (up - 2*u + um) / dx^2;

    % advection derivative u_x (upwind)
    ux_fwd = (up - u) / dx;
    ux_bwd = (u - um) / dx;

    % choose upwind based on sign(u)
    ux = ux_bwd;
    pos = (u < 0);
    ux(pos) = ux_fwd(pos);

    dudt = -u .* ux + nu * u_xx;
end
