% Solve over time interval [0,100] with initial conditions [1,1,1]
% ''f'' is set of differential equations
% ''a'' is array containing x, y, and z variables
% ''t'' is time variable
close all; clear;
rr=colormap('hsv');


sigma = 10;
beta = 8/3;
rho = 28;

tend = 101;


X0=[9 5 5];
xd = .05;
sp = .005;

xics = X0(1)-xd:sp:X0(1)+xd;
yics = X0(2)-xd:sp:X0(2)+xd;
zics = X0(3)-xd:sp:X0(3)+xd;
f = @(t,a) [-sigma*a(1) + sigma*a(2); rho*a(1) - a(2) - a(1)*a(3); -beta*a(3) + a(1)*a(2)];

ctr=1;
zout = zeros(length(xics)^3,3);
for xx = xics
    for yy = yics
        for zz = zics
            xint=[xx yy zz];
            [t,a] = ode45(f,[0 tend],xint);
            zout(ctr,:)=a(end,:);
            ctr=ctr+1;
        end
    end
end
save('Lorenz_out.mat');
