% MyFirstODEsolve will solve the 
% ODE dy/dt = 2t with y(0) = 0 and plot the solution y(t)

tspan = [0 5];  % The time span here is an option to put into the ODE solver (ode45)
y0 = 0;         % The initial condition is an option to put into the ODE solver

[t,y] = ode45(@(t,y) 2*t, tspan, y0);  % The first argument @(t,y) defines 
                                       % a function of t,y to be 2*t so the 
                                       % solver knows it is solving the ODE
                                       % dy/dt = 2*t
                                       % the second argument is the time
                                       % span and the third argument is the
                                       % intial condition
                                       % The solver will solve the ODE
                                       % starting at the initial condition
                                       % over the time span

plot(t,y,'LineWidth',4);                             % Make a simple plot
xlabel('t');
ylabel('y');
title('Solution of ODE dy/dt = 2t');
grid on;
set(gca,"FontSize",24)
shg
