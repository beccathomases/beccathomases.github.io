x=0:.25:10;
y = sin(x);
f = plot(x,y,'+--','MarkerSize',12);
xlabel('x');
ylabel('sin(x)');
title('My first MATLAB plot');
set(f,'color',[1/256;25/256;200/256]);
set(f,'LineWidth',4);
set(gca,'fontsize',24);
%axis([0 5 -1 1]);
shg

saveas(gca,'fig1.fig','fig');  % this will save the current figure as a .fig file
saveas(gca,'fig1.pdf','pdf');  % this will save as a pdf
