S = load('agent_reinforce_4x4_k3.mat', 'policy', 'metadata');
policy   = S.policy;

ROWS      = S.metadata.ROWS;
COLS      = S.metadata.COLS;
CONNECT_K = S.metadata.CONNECT_K;
MAX_MOVES = S.metadata.MAX_MOVES;

env = makeConnectKEnv(ROWS, COLS, CONNECT_K, MAX_MOVES);

human_player = 1;
playHumanVsAgent(env, policy, human_player);


% Helper functions below

function env = makeConnectKEnv(rows, cols, connect_k, max_moves)
    env.rows      = rows;
    env.cols      = cols;
    env.connect_k = connect_k;
    env.max_moves = max_moves;
    env = resetEnv(env);
end

function env = resetEnv(env)
    env.board          = zeros(env.rows, env.cols); % 0 = empty, 1 or -1 = players
    env.currentPlayer  = 1;  % 1 (X) or -1 (O)
    env.numMoves       = 0;
    env.winner         = 0;
end

function legal = legalMoves(env)
    % legal(c) = true if top cell in column c is empty
    legal = env.board(1,:) == 0;
end

function [env, row] = dropPiece(env, col)
    % Drop piece for currentPlayer in given column (assumed legal).
    % Returns updated env and row index where it landed.
    for r = env.rows:-1:1
        if env.board(r, col) == 0
            env.board(r, col) = env.currentPlayer;
            row = r;
            return;
        end
    end
    error('dropPiece called on full column');
end

function won = checkWin(env, r, c)
    % True if placing at (r,c) created CONNECT_K for that player.
    player = env.board(r,c);
    if player == 0
        won = false;
        return;
    end
    dirs = [0 1; 1 0; 1 1; 1 -1]; % horiz, vert, diag, anti-diag
    for k = 1:size(dirs,1)
        dr = dirs(k,1); dc = dirs(k,2);
        if countDirection(env, r, c, dr, dc, player) >= env.connect_k
            won = true;
            return;
        end
    end
    won = false;
end

function count = countDirection(env, r, c, dr, dc, player)
    count = 1;
    % forward
    rr = r + dr; cc = c + dc;
    while rr >= 1 && rr <= env.rows && cc >= 1 && cc <= env.cols ...
          && env.board(rr,cc) == player
        count = count + 1;
        rr = rr + dr;
        cc = cc + dc;
    end
    % backward
    rr = r - dr; cc = c - dc;
    while rr >= 1 && rr <= env.rows && cc >= 1 && cc <= env.cols ...
          && env.board(rr,cc) == player
        count = count + 1;
        rr = rr - dr;
        cc = cc - dc;
    end
end

function [env, reward, done] = stepEnv(env, actionCol)
    % Take an action (column index, 1..env.cols).
    % Reward is 0 here; final reward is assigned at end of episode.
    done   = false;
    reward = 0;

    legal = legalMoves(env);
    if actionCol < 1 || actionCol > env.cols || ~legal(actionCol)
        % Illegal move: small penalty & switch player, but don't place piece.
        % This discourages illegal moves during training.
        reward = -0.1;
        env.currentPlayer = -env.currentPlayer;
        env.numMoves = env.numMoves + 1;
        if env.numMoves >= env.max_moves
            done = true;
        end
        return;
    end

    [env, rowPlaced] = dropPiece(env, actionCol);
    env.numMoves = env.numMoves + 1;

    if checkWin(env, rowPlaced, actionCol)
        env.winner = env.currentPlayer;
        done = true;
        return;
    end

    if env.numMoves >= env.max_moves
        done = true;
        env.winner = 0; % draw
        return;
    end

    env.currentPlayer = -env.currentPlayer;
end

function printBoard(env)
    % X = 1, O = -1, . = empty
    fprintf('   ');
    for c = 1:env.cols
        fprintf('%d ', c);
    end
    fprintf('\n');
    for r = 1:env.rows
        fprintf('%2d ', r);
        for c = 1:env.cols
            v = env.board(r,c);
            if v == 1
                ch = 'X';
            elseif v == -1
                ch = 'O';
            else
                ch = '.';
            end
            fprintf('%s ', ch);
        end
        fprintf('\n');
    end
    fprintf('\n');
end
function s = boardToState(env)
    % Board from current player's perspective as a column vector.
    % 1 = my piece, -1 = opponent, 0 = empty
    b = env.currentPlayer * env.board;    % still ROWS x COLS
    s = b(:);                             % flatten to (ROWS*COLS) x 1
end

function [action, logp, probs] = sampleAction(policy, s, legalMask, temperature)
    % policy.W: [numActions x stateDim]
    % policy.b: [numActions x 1]
    % s: stateDim x 1
    % legalMask: logical row vector (1 x numActions)

    logits = policy.W * s + policy.b;  % numActions x 1

    % Mask illegal moves by -Inf (approx with large negative)
    masked_logits = logits;
    illegal = ~legalMask(:);
    masked_logits(illegal) = -1e9;

    if temperature > 0
        z = masked_logits / temperature;
    else
        z = masked_logits;
    end

    % Softmax
    zmax = max(z);
    expz = exp(z - zmax);
    probs = expz / sum(expz);

    % Sample action according to probs
    edges  = [0; cumsum(probs)];
    u      = rand();
    a_idx  = find(u >= edges(1:end-1) & u < edges(2:end), 1, 'first');
    action = a_idx;  % 1..numActions

    logp = log(probs(action) + 1e-12);
end

function [traj, result_p1] = playSelfPlayEpisode(env, policy, temperature)
    % traj will store:
    %   states:   cell array of column vectors s_t
    %   actions:  vector of column indices
    %   players:  vector of +1/-1 for each move

    env = resetEnv(env);

    states  = {};
    actions = [];
    players = [];

    done = false;

    while ~done
        s = boardToState(env);
        legal = legalMoves(env);          % 1 x cols logical

        [a, logp, probs] = sampleAction(policy, s, legal, temperature); %#ok<ASGLU>

        states{end+1}  = s;        %#ok<AGROW>
        actions(end+1) = a;        %#ok<AGROW>
        players(end+1) = env.currentPlayer; %#ok<AGROW>

        [env, ~, done] = stepEnv(env, a);
    end

    % Determine outcome from player-1 perspective
    if env.winner == 1
        result_p1 = 1;
    elseif env.winner == -1
        result_p1 = -1;
    else
        result_p1 = 0;
    end

    traj.states  = states;
    traj.actions = actions;
    traj.players = players;
end
function policy = reinforceUpdate(policy, traj, result_p1, gamma, lr)

    states  = traj.states;
    actions = traj.actions;
    players = traj.players;

    T = numel(actions);
    rewards = zeros(T,1);

    % Terminal reward from player-1 perspective
    % Each move by player p gets reward: result_p1 if p=1, else -result_p1
    if result_p1 == 0
        rewards(:) = 0;
    else
        for t = 1:T
            if players(t) == 1
                rewards(t) = result_p1;
            else
                rewards(t) = -result_p1;
            end
        end
    end

    % Compute returns G_t (here gamma=1 by default, so just all same)
    G = zeros(T,1);
    running = 0;
    for t = T:-1:1
        running = rewards(t) + gamma * running;
        G(t) = running;
    end

    % Optional: baseline / normalization of returns
    if std(G) > 1e-8
        G = (G - mean(G)) / std(G);
    end

    % Accumulate gradient over trajectory
    dW = zeros(size(policy.W));
    db = zeros(size(policy.b));

    numActions = size(policy.W,1);

    for t = 1:T
        s = states{t};
        a = actions(t);
        g = G(t);

        logits = policy.W * s + policy.b;
        zmax   = max(logits);
        expz   = exp(logits - zmax);
        p      = expz / sum(expz);   % softmax

        % grad wrt logits: G * (p - one_hot(a))
        grad_logits = g * p;
        grad_logits(a) = grad_logits(a) - g;

        % dW += grad_logits * s^T
        dW = dW + grad_logits * s';
        db = db + grad_logits;
    end

    % Gradient descent
    policy.W = policy.W - lr * dW;
    policy.b = policy.b - lr * db;
end
function playHumanVsAgent(env, policy, human_player)
    env = resetEnv(env);
    fprintf('You are player %d (%s)\n', human_player, ternary(human_player==1,'X','O'));

    done = false;
    while ~done
        printBoard(env);

        if env.currentPlayer == human_player
            fprintf('Your move. Choose a column (1..%d): ', env.cols);
            col = input('');
            if isempty(col) || ~isscalar(col)
                fprintf('Invalid input.\n');
                continue;
            end
            action = round(col);
        else
            % Agent move
            s = boardToState(env);
            legal = legalMoves(env);
            temperature = 0.0; % greedy
            [action, ~, ~] = sampleAction(policy, s, legal, temperature);
            fprintf('Agent plays column %d\n', action);
        end

        [env, ~, done] = stepEnv(env, action);
    end

    printBoard(env);
    if env.winner == 0
        fprintf('Game over: DRAW.\n');
    elseif env.winner == human_player
        fprintf('Game over: YOU WIN!\n');
    else
        fprintf('Game over: you lose.\n');
    end
end

function out = ternary(cond, a, b)
    if cond
        out = a;
    else
        out = b;
    end
end
