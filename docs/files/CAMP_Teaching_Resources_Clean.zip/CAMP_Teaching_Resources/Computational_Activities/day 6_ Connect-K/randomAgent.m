function col = randomAgent(board, player, legalMoves)
    legalIdx = find(legalMoves);
    col = legalIdx(randi(numel(legalIdx)));
end
