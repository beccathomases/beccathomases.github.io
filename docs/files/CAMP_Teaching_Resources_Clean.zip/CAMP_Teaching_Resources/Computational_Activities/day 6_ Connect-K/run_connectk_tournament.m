function results = run_connectk_tournament(agent1, agent2, ROWS, COLS, CONNECT_K, N_GAMES, verbose)
%RUN_CONNECTK_TOURNAMENT  Play many games of Connect-K: agent1 vs agent2.
%
%   results = run_connectk_tournament(agent1, agent2, ROWS, COLS, CONNECT_K, N_GAMES, verbose)
%
%   agent1, agent2 : function handles of the form
%                    col = agentFun(board, player, legalMoves)
%
%   ROWS, COLS     : board size
%   CONNECT_K      : how many in a row to win
%   N_GAMES        : number of games to play
%   verbose        : (optional) if true, prints per-game summary
%
%   results is a struct with fields:
%       .agent1_wins
%       .agent2_wins
%       .draws
%       .winners          (length N_GAMES,  1 -> agent1, -1 -> agent2, 0 -> draw)
%       .starting_player  (length N_GAMES,  1 or -1 for player who moved first)

    if nargin < 7
        verbose = false;
    end

    % Stats
    agent1_wins = 0;
    agent2_wins = 0;
    draws       = 0;

    winners         = zeros(N_GAMES, 1);  % 1 = agent1, -1 = agent2, 0 = draw
    starting_player = zeros(N_GAMES, 1);  % +1 or -1

    MAX_MOVES = ROWS * COLS;

    for g = 1:N_GAMES
        % Alternate who starts: odd games -> agent1 as player +1, even -> agent2
        if mod(g,2) == 1
            % Game g: agent1 is player +1, agent2 is player -1
            mapping = struct('p1_agent', 1, 'p2_agent', 2);
        else
            % Game g: agent2 is player +1, agent1 is player -1
            mapping = struct('p1_agent', 2, 'p2_agent', 1);
        end

        starting_player(g) = +1;

        board  = zeros(ROWS, COLS);  % 0 empty
        player = +1;                 % +1 always starts in this representation

        winner = 0;  % 0 = not decided, 1 or -1 = player, 2 = draw sentinel

        for move = 1:MAX_MOVES
            legalMoves = getLegalMoves(board);
            if ~any(legalMoves)
                % Board full, no winner -> draw
                winner = 2;
                break;
            end

            % Choose which agent is acting this turn
            if player == +1
                which_agent = mapping.p1_agent;
            else
                which_agent = mapping.p2_agent;
            end

            if which_agent == 1
                col = agent1(board, player, legalMoves);
            else
                col = agent2(board, player, legalMoves);
            end

            % Safety: if agent picks illegal move, replace with random legal
            if col < 1 || col > COLS || ~legalMoves(col)
                if verbose
                    fprintf('[Game %d] Player %d chose illegal move %d. Replacing with random legal.\n', ...
                            g, player, col);
                end
                legalIdx = find(legalMoves);
                col = legalIdx(randi(numel(legalIdx)));
            end

            % Apply move
            board = dropPiece(board, col, player);

            % Check for win
            if checkWinner(board, player, CONNECT_K)
                winner = player;
                break;
            end

            % Switch player
            player = -player;
        end

        % Interpret winner
        if winner == 2 || winner == 0
            draws = draws + 1;
            winners(g) = 0;
            if verbose
                fprintf('Game %d: draw.\n', g);
            end
        else
            % winner is +1 or -1 (player in board space).
            % Map back to "agent1"/"agent2".
            if winner == +1
                who_agent = mapping.p1_agent;
            else
                who_agent = mapping.p2_agent;
            end

            if who_agent == 1
                agent1_wins = agent1_wins + 1;
                winners(g)  = 1;
                if verbose
                    fprintf('Game %d: agent1 wins (as player %d).\n', g, winner);
                end
            else
                agent2_wins = agent2_wins + 1;
                winners(g)  = -1;
                if verbose
                    fprintf('Game %d: agent2 wins (as player %d).\n', g, winner);
                end
            end
        end
    end

    % Pack results
    results = struct();
    results.agent1_wins     = agent1_wins;
    results.agent2_wins     = agent2_wins;
    results.draws           = draws;
    results.winners         = winners;
    results.starting_player = starting_player;

    fprintf('\n===== Tournament summary (%d games) =====\n', N_GAMES);
    fprintf('Agent 1 wins: %d\n', agent1_wins);
    fprintf('Agent 2 wins: %d\n', agent2_wins);
    fprintf('Draws       : %d\n', draws);
end

% -------------------------------------------------------
% Helper: where is it legal to play?
function legalMoves = getLegalMoves(board)
    [ROWS, COLS] = size(board);
    legalMoves = false(1, COLS);
    for c = 1:COLS
        % Legal if top cell is empty (so at least one spot in column)
        if board(1,c) == 0
            legalMoves(c) = true;
        end
    end
end

% -------------------------------------------------------
% Helper: drop a piece in a column for `player` (+1 or -1).
function board = dropPiece(board, col, player)
    [ROWS, ~] = size(board);
    for r = ROWS:-1:1
        if board(r,col) == 0
            board(r,col) = player;
            return;
        end
    end
    % If we get here something went wrong; just leave board as is.
end

% -------------------------------------------------------
% Helper: check K-in-a-row for this player.
function won = checkWinner(board, player, K)
    [ROWS, COLS] = size(board);

    % Horizontal
    for r = 1:ROWS
        for c = 1:(COLS-K+1)
            if all(board(r, c:(c+K-1)) == player)
                won = true; return;
            end
        end
    end

    % Vertical
    for c = 1:COLS
        for r = 1:(ROWS-K+1)
            if all(board(r:(r+K-1), c) == player)
                won = true; return;
            end
        end
    end

    % Diagonal down-right
    for r = 1:(ROWS-K+1)
        for c = 1:(COLS-K+1)
            ok = true;
            for k = 0:(K-1)
                if board(r+k, c+k) ~= player
                    ok = false; break;
                end
            end
            if ok
                won = true; return;
            end
        end
    end

    % Diagonal up-right
    for r = K:ROWS
        for c = 1:(COLS-K+1)
            ok = true;
            for k = 0:(K-1)
                if board(r-k, c+k) ~= player
                    ok = false; break;
                end
            end
            if ok
                won = true; return;
            end
        end
    end

    won = false;
end
