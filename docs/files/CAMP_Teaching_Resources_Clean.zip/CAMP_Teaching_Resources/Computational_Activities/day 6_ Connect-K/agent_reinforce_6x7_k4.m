function col = agent_reinforce_6x7_k4(board, player, legalMoves)
%AGENT_REINFORCE_4X4_K3  Greedy agent using a saved REINFORCE policy.
%
%   col = agent_reinforce_4x4_k3(board, player, legalMoves)
%
%   board      : ROWS x COLS numeric matrix
%                (you must match whatever your env uses: 0/1/2 or -1/0/1)
%   player     : 1 or 2 (or 1/-1, depending on your env)
%   legalMoves : 1 x COLS logical, true where move allowed
%   col        : chosen column index (1..COLS)
%
%   This assumes you've run training and saved:
%       save('agent_reinforce_4x4_k3.mat','policy','metadata');

    persistent policy_loaded metadata_loaded

    if isempty(policy_loaded)
        S = load('agent_reinforce_6x7_k4.mat', 'policy', 'metadata');
        policy_loaded   = S.policy;
        metadata_loaded = S.metadata;
    end

    ROWS = metadata_loaded.ROWS;
    COLS = metadata_loaded.COLS;

    % --- build state vector from board + player perspective ---
    phi = boardToStateVec(board, player, ROWS, COLS);   % column vector (state_dim x 1)

    % --- linear logits ---
    logits = policy_loaded.W * phi + policy_loaded.b;    % (COLS x 1)

    % --- mask illegal moves ---
    logits = logits(:);                   % ensure column
    legalMoves = logical(legalMoves(:));  % COLS x 1
    logits(~legalMoves) = -inf;

    % --- greedy action (no sampling here) ---
    [~, col] = max(logits);
end

function phi = boardToStateVec(board, player, ROWS, COLS)
% Convert board into a column feature vector from *current player's* POV.
%
% You MUST match this to whatever you used inside playSelfPlayEpisode /
% reinforceUpdate. Two common patterns are shown below; uncomment the one
% that matches your encoding.

    board = double(board);

    % ----- Option A: env uses values in {-1, 0, +1} -----
    % (current player = +1, opponent = -1)
    % In that case, you can just multiply by `player` to get POV features:
    %
    %   phi = (player .* board)(:)    % current player's pieces -> +1
    %
    % Uncomment if that's your convention:
    %phi = (player .* board)';
    %phi = phi(:);

    % ----- Option B: env uses 0 (empty), 1 (P1), 2 (P2) -----
    % Here we encode "my pieces" as +1, "opponent" as -1, empty as 0.

    if max(board(:)) <= 2 && min(board(:)) >= 0
        if player == 1
            myMask  = (board == 1);
            oppMask = (board == 2);
        else
            myMask  = (board == 2);
            oppMask = (board == 1);
        end
        phi = double(myMask - oppMask);   % my squares +1, opp squares -1
        phi = phi(:);                     % column vector
    else
        % Fallback: just flatten raw board (you can replace this)
        phi = board(:);
    end

    % Sanity check on length
    if numel(phi) ~= ROWS * COLS
        error('boardToStateVec: size mismatch, got %d features, expected %d', ...
              numel(phi), ROWS*COLS);
    end
end
