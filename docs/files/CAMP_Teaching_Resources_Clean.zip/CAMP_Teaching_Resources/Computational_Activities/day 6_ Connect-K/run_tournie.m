ROWS = 4; COLS = 4; CONNECT_K = 3;
N_GAMES = 200;

results = run_connectk_tournament(@agent_reinforce_4x4_k3, @randomAgent, ...
                                  ROWS, COLS, CONNECT_K, N_GAMES, true);
