ROWS = 6; COLS = 7; CONNECT_K = 4;

% REINFORCE agent vs random
connectk_gui_agents(@agent_reinforce_6x7_k4, @randomAgent, ROWS, COLS, CONNECT_K, 0.4);

% REINFORCE agent vs another student agent
%connectk_gui_agents(@agent_reinforce_4x4_k3, @agent_1_4x4_k3, ROWS, COLS, CONNECT_K, 0.4);
