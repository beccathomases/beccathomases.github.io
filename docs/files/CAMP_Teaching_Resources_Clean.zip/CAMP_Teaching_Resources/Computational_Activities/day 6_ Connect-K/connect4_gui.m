function connect4_gui()
%CONNECT4_GUI  Simple GUI for a human-vs-human Connect 4 game.
%   Click in a column to drop a disc.
%   Player 1 = red, Player 2 = yellow.
%
%   Close the window to quit.

    % Board size and game parameters
    rows = 6;
    cols = 7;
    connectN = 4;

    % 0 = empty, 1 = Player 1, 2 = Player 2
    board = zeros(rows, cols);
    currentPlayer = 1;
    gameOver = false;

    % --- Figure and axes setup ---
    fig = figure('Name','Connect 4', ...
                 'NumberTitle','off', ...
                 'MenuBar','none', ...
                 'ToolBar','none', ...
                 'Color',[0.9 0.9 0.9], ...
                 'Units','normalized', ...
                 'Position',[0.3 0.2 0.4 0.6]);

    % Main axes for the board
    ax = axes('Parent',fig, ...
              'Units','normalized', ...
              'Position',[0.1 0.15 0.8 0.8]);
    hold(ax,'on');
    axis(ax,'equal');
    xlim(ax,[0.5, cols+0.5]);
    ylim(ax,[0.5, rows+0.5]);
    set(ax,'XTick',1:cols, 'YTick',1:rows, ...
           'XTickLabel',[], 'YTickLabel',[], ...
           'YDir','reverse', 'Box','on');

    % Button for a new game
    uicontrol('Parent',fig, ...
              'Style','pushbutton', ...
              'String','New game', ...
              'Units','normalized', ...
              'Position',[0.35 0.03 0.3 0.06], ...
              'FontSize',12, ...
              'Callback',@newGameCallback);

    % Set clicking callback
    set(fig,'WindowButtonDownFcn',@mouseClickCallback);

    % Draw initial empty board
    redrawBoard();
    updateTitle();

    % ================== Nested functions ==================

    function redrawBoard()
        % Clear and redraw the entire board based on the "board" matrix
        cla(ax);

        % Blue background board
        rectangle('Parent',ax, ...
                  'Position',[0.5 0.5 cols rows], ...
                  'FaceColor',[0 0.3 0.8], ...
                  'EdgeColor','none');

        % Draw each cell as a circle: white = empty, red/yellow = tokens
        for r = 1:rows
            for c = 1:cols
                switch board(r,c)
                    case 0
                        faceColor = [1 1 1];       % empty = white
                    case 1
                        faceColor = [0.9 0 0];     % player 1 = red
                    case 2
                        faceColor = [1 0.85 0.1];  % player 2 = yellow
                    otherwise
                        faceColor = [0 0 0];
                end

                rectangle('Parent',ax, ...
                          'Position',[c-0.4, r-0.4, 0.8, 0.8], ...
                          'Curvature',[1 1], ...
                          'FaceColor',faceColor, ...
                          'EdgeColor','k', ...
                          'LineWidth',1);
            end
        end

        axis(ax,[0.5 cols+0.5 0.5 rows+0.5]);
        axis(ax,'equal');
        set(ax,'XTick',1:cols,'YTick',1:rows, ...
               'XTickLabel',[], 'YTickLabel',[], ...
               'YDir','reverse','Box','on');
    end

    function updateTitle()
        if ~gameOver
            if currentPlayer == 1
                title(ax,'Player 1 (red) to move','FontSize',14);
            else
                title(ax,'Player 2 (yellow) to move','FontSize',14);
            end
        end
    end

    function mouseClickCallback(~,~)
        % Handle mouse click: drop a piece in the clicked column
        if gameOver
            return;
        end

        cp = get(ax,'CurrentPoint');
        x = cp(1,1);
        y = cp(1,2);

        % Only accept clicks inside the board bounds
        if x < 0.5 || x > cols+0.5 || y < 0.5 || y > rows+0.5
            return;
        end

        col = round(x);
        if col < 1 || col > cols
            return;
        end

        % Find lowest empty row in this column
        r = find(board(:,col)==0, 1, 'last');
        if isempty(r)
            % Column is full, ignore click
            return;
        end

        % Place the piece
        board(r,col) = currentPlayer;
        redrawBoard();

        % Check for win or draw
        if checkWin(board, currentPlayer, connectN)
            title(ax, sprintf('Player %d wins!', currentPlayer), 'FontSize',14);
            gameOver = true;
            return;
        elseif all(board(:) ~= 0)
            title(ax, 'Draw game', 'FontSize',14);
            gameOver = true;
            return;
        else
            % Switch player
            currentPlayer = 3 - currentPlayer;  % 1 <-> 2
            updateTitle();
        end
    end

    function newGameCallback(~,~)
        % Reset the board and state for a new game
        board(:) = 0;
        currentPlayer = 1;
        gameOver = false;
        redrawBoard();
        updateTitle();
    end

end

% ================== Win check helper ==================
function win = checkWin(board, player, connectN)
%CHECKWIN  Return true if "player" has connectN in a row on "board".

    [rows, cols] = size(board);
    win = false;

    % Directions: right, down, diag down-right, diag down-left
    dirs = [ 0  1;   % horizontal
             1  0;   % vertical
             1  1;   % diagonal down-right
             1 -1];  % diagonal down-left

    for r = 1:rows
        for c = 1:cols
            if board(r,c) ~= player
                continue;
            end
            for d = 1:size(dirs,1)
                dr = dirs(d,1);
                dc = dirs(d,2);
                count = 1;
                rr = r;
                cc = c;

                while true
                    rr = rr + dr;
                    cc = cc + dc;
                    if rr < 1 || rr > rows || cc < 1 || cc > cols
                        break;
                    end
                    if board(rr,cc) == player
                        count = count + 1;
                        if count >= connectN
                            win = true;
                            return;
                        end
                    else
                        break;
                    end
                end
            end
        end
    end
end
