# Instructor notes — Leaf-image measurement (CAMP)

**Suggested schedule (75 minutes)**
- 10 min: What is an image as data? Define segmentation and pixel units.
- 15 min: Run script; inspect image, grayscale, and binary mask.
- 20 min: Change thresholds and compare measured areas and perimeters.
- 15 min: Introduce shadow image; discuss failure modes and robustness.
- 15 min: Students document an observation, a limitation, and a next experiment.

## What the exercise is designed to reveal
- Many thresholds may give similar measurements on the clean synthetic image, but performance can change under different lighting.
- A grid-based perimeter is an imperfect approximation of geometric length and can be sensitive to jagged boundaries and image scale.
- Pixel counts are not physical measurements until the spatial calibration is known.
- A research workflow includes testing sensitivity, validating assumptions, and communicating uncertainty.

## Practical notes
The MATLAB script uses only core matrix, image display, and plotting operations. The optional extensions may use Image Processing Toolbox functionality (`regionprops`, `imbinarize`, etc.), but the core activity does not require it. Keep the exercise exploratory: there is no single universally optimal threshold.

For broader distribution, the bundled pictures are generated/synthetic so no dataset license is needed. If using students' own photos, avoid faces, addresses, GPS metadata, and other unrelated personal content.

