# CAMP activity: What does it mean to measure a leaf from a photograph?
**Estimated time:** 60–90 minutes  
**Tools:** MATLAB and supplied images

## Research question
Can you measure the area and shape of a leaf from a photograph? How certain should you be about the answer?

### Part A — Build a measurement
1. Run `leaf_measurement.m` on `leaf_clean.png`. Identify how a color image becomes an array of pixel values and then a binary leaf mask.
2. Record your chosen threshold, measured area (square pixels), perimeter (pixel-edge units), and circularity estimate.
3. Explain in 2–3 sentences what the threshold actually means.

### Part B — Test your assumptions
4. Explore at least **five** threshold values. Are the results stable? Sketch or save the area-versus-threshold plot.
5. Switch to `leaf_shadow.png`. Does the same threshold still produce a convincing mask? Describe why or why not.
6. Which measurement appears more sensitive: area or perimeter? Why might the boundary measurement be especially sensitive to noise?

### Part C — Report like a researcher
Write a short memo (about half a page) stating your measurement method, a reasonable threshold range, one source of uncertainty, and a next experiment that could improve the estimate. Include at least one figure.

## Optional extensions
- **Calibration:** Put a ruler in a photograph. Convert pixel measurements to cm and cm². What assumptions are involved?
- **Comparison:** Analyze two leaves photographed under similar conditions. Is their circularity different?
- **Validation:** Compare your automated mask to a manually traced outline and quantify disagreement.
- **Robustness:** Blur an image, change contrast, rotate it, or resize it. How do your measurements change?
- **Alternative approach:** For real color photos, can a color-based mask outperform the simple grayscale threshold?

**Key point:** A numerical answer is not automatically a reliable measurement. Document the decisions that produced it.
