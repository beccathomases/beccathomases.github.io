%% CAMP: Measuring a leaf from an image
% Run this script from the folder containing the supplied PNG files.
% Requires base MATLAB (no Image Processing Toolbox).
clear; close all; clc;

%% 1. Load image and inspect it
filename = 'leaf_clean.png';  % try 'leaf_shadow.png' next 
                              % for more "biological" versions try 
                              % 'natural_leaf.png' and
                              % 'natural_leaf_shadow_1.png' or 'natural_leaf_shadow_2.png'

rgb = imread(filename);
figure(1); image(rgb); axis image off;
title(['Original image: ', filename], 'Interpreter','none');

%% 2. Convert to grayscale (weighted RGB luminance)
rgbDouble = double(rgb);
gray = 0.299*rgbDouble(:,:,1) + 0.587*rgbDouble(:,:,2) + ...
       0.114*rgbDouble(:,:,3);
figure(2);
imagesc(gray);
colormap(gca, 'gray');
colorbar;

axis image off; title('Grayscale brightness (0 to 255)');

%% 3. Segment the darker leaf from the lighter background
threshold = 155; % Try 105, 125, 155, 175, 195
mask = gray < threshold;
figure(3);
imagesc(mask);
colormap(gca, 'gray');
axis image off;

title(sprintf('Binary mask, threshold = %g', threshold));

%% 4. Measure area and perimeter in pixel units
% Area = number of foreground pixels. Perimeter = number of
% foreground/background edges on the square pixel grid.
areaPx = nnz(mask);
padded = false(size(mask)+2);
padded(2:end-1,2:end-1) = mask;
perimeterPx = sum(abs(diff(double(padded),1,1)), 'all') + ...
              sum(abs(diff(double(padded),1,2)), 'all');
circularity = 4*pi*areaPx / (perimeterPx^2);
fprintf('\nImage: %s\n', filename);
fprintf('Threshold: %.0f\n', threshold);
fprintf('Area: %d square pixels\n', areaPx);
fprintf('Grid perimeter: %.0f pixel-edge units\n', perimeterPx);
fprintf('Circularity (grid estimate): %.3f\n', circularity);
% NOTE: perimeter is grid based and changes with pixel resolution and rotation.
% Without a ruler or known scale, do NOT report physical area (e.g., cm^2).

%% 5. Sensitivity experiment: how much does threshold choice matter?
thresholds = 95:10:215;
areas = zeros(size(thresholds));
perimeters = zeros(size(thresholds));
for k = 1:numel(thresholds)
    candidate = gray < thresholds(k);
    areas(k) = nnz(candidate);
    pad = false(size(candidate)+2);
    pad(2:end-1,2:end-1) = candidate;
    perimeters(k) = sum(abs(diff(double(pad),1,1)), 'all') + ...
                    sum(abs(diff(double(pad),1,2)), 'all');
end
figure(4);
plot(thresholds,areas,'o-','LineWidth',1.5); grid on;
xlabel('Brightness threshold'); ylabel('Estimated area (square pixels)');
title('Sensitivity of area to threshold choice');
figure(5);
plot(thresholds,perimeters,'o-','LineWidth',1.5); grid on;
xlabel('Brightness threshold'); ylabel('Grid perimeter (pixel edges)');
title('Sensitivity of perimeter to threshold choice');

%% Questions to investigate
% A. Which thresholds give plausible leaf masks? Can you justify your choice?
% B. When you switch to leaf_shadow.png, does your chosen threshold still work?
% C. Is area or perimeter more sensitive to the threshold? Why might that be?
% D. What assumptions would be needed to convert pixel area to cm^2?
% E. Extension: Photograph your own leaf on a plain background. Where does
%    this simple segmentation method fail, and how could you improve it?
