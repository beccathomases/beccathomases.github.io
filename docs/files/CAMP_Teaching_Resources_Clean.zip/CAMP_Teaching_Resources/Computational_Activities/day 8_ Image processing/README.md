# CAMP computational activity: Measuring leaf shapes from images

**Audience:** Undergraduates with basic MATLAB familiarity.  **Time:** 60–90 minutes guided, with optional extensions.  **Software:** Base MATLAB, no additional toolboxes required. Students can progress from simple synthetic images to more realistic photographs, investigating how texture, illumination, and shadows affect the accuracy of computational measurements.

## Learning goals
- Represent a color image numerically and create a binary segmentation mask.
- Estimate leaf area and outline length from pixels.
- Investigate how a computational choice (brightness threshold) affects a reported measurement.
- Articulate assumptions and limitations rather than treating software output as ground truth.

## Files

- `leaf_measurement.m` — runnable MATLAB script for the activity.
- `leaf_clean.png` — synthetic green leaf on a light background; a simple baseline for segmentation.
- `leaf_shadow.png` — synthetic leaf with uneven background illumination.
- `natural_leaf.png` — realistic leaf on a uniform light background, providing a more detailed but relatively straightforward segmentation example.
- `natural_leaf_shadow_1.png` — realistic leaf with uneven lighting and shadows, introducing additional segmentation challenges.
- `natural_leaf_shadow_2.png` — realistic leaf with strong shadows crossing the leaf and background, demonstrating limitations of simple grayscale thresholding.
- `Student_Activity.md` — handout questions and optional project extensions.
- `Instructor_Notes.md` — pacing, expected observations, and adaptation guidance.

## Getting started
1. Download/unzip all files into one folder.
2. In MATLAB, set the **Current Folder** to the folder containing `leaf_measurement.m` and the two PNGs.
3. Open `leaf_measurement.m` and click **Run**.
4. Explore the segmentation results and threshold-sensitivity plots.
5. Change `filename` from `leaf_clean.png` to `leaf_shadow.png`, rerun, and compare.

## Notes on reuse
The two PNGs were generated synthetically specifically for this teaching exercise. They are **illustrations, not experimental leaf measurements**. No student records or external research images are included. Replace them with student photographs or permissively licensed leaf images to extend the activity.

The script uses a basic pixel-grid perimeter estimate, so values can depend on orientation and resolution. Measurements remain in pixel units unless a physical scale is supplied. MATLAB releases that do not support `sum(A,'all')` can replace it with `sum(A(:))`.
